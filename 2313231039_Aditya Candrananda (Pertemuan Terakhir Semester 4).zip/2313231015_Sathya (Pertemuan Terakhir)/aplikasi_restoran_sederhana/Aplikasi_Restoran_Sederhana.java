/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aplikasi_restoran_sederhana;

/**
 *
 * @author LENOVO
 */
public class Aplikasi_Restoran_Sederhana {
    public static void main(String[] args) {
        Login l = new Login();
        l.setVisible(true);
    }
}
